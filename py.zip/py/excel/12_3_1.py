import openpyxl

wb = openpyxl.load_workbook('example.xlsx')
print( type(wb) )

print("==========================0")

print( wb.get_sheet_names() )

sheet = wb.get_sheet_by_name('Sheet3')
print( sheet )
print( type(sheet) )
print( sheet.title )

another_sheet = wb.active
print( another_sheet )

print("==========================1")
sheet = wb.get_sheet_by_name('Sheet1')

print( sheet['A1'] )
print( sheet['A1'].value )
# c = sheet['B1']
# print( c.value )
# print( '行' + str(c.row) + ',列 ' + 'c.column' + ' は ' + c.value )
# print( 'セル' + c.coordinate + ' は ' + c.value )

# print( sheet['C1'].value )

print("==========================2")

print( sheet.cell(row=1, column=2) )
print( sheet.cell(row=1, column=2).value )
for i in range(1, 8, 2):
    print( i, sheet.cell(row=i, column=2).value )

print("==========================12.3.3")
print( sheet.max_row )
print( sheet.max_column )

print("==========================12.2.4")

# errorのため確認せず
# from openpyxl.cell import get_column_letter, column_index_from_string

# print( get_column_letter(1) )
# print( get_column_letter(2) )
# print( get_column_letter(27) )
# print( get_column_letter(900) )
# print( get_column_letter(sheet.max_column) )
# print( column_index_from_string('A') )
# print( column_index_from_string('AA') )


print("==========================12.2.5")

print( tuple(sheet['A1':'C3']) )
for row_of_cell_objects in sheet['A1':'C3']:        # #1
    for cell_obj in row_of_cell_objects:            # #2
        print( cell_obj.coordinate, cell_obj.value, type(cell_obj.value) )
    print('--- END OF ROW ---')

for row_of_cell_objects in sheet['A1':'A8']:        # #1
    for cell_obj in row_of_cell_objects:            # #2
        print( cell_obj.coordinate, cell_obj.value )
    print('--- END OF ROW ---')


# print( sheet.columns[1] )
print( list(sheet.columns)[1] )

# for cell_obj in sheet.columns[1]:
#     print(cell_obj.value)
for cell_obj in list(sheet.columns)[1]:
    print(cell_obj.value)


print("==========================6")
print("==========================7")
print("==========================8")
print("==========================9")
print("==========================10")
print("==========================11")
print("==========================12")


print("==========================13")
