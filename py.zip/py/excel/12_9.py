print("==========================12.9.1")
# import openpyxl

# wb = openpyxl.Workbook()
# print( wb.get_sheet_names() )
# sheet = wb.active
# sheet['A1'] = 200
# sheet['A2'] = 300
# sheet['A3'] = '=SUM(A1:A2)'
# wb.save('writeFormula.xlsx')


print("==========================12.9.2")
import openpyxl

wb_formulas = openpyxl.load_workbook('writeFormula.xlsx')
sheet = wb_formulas.active
print(sheet['A3'].value)

wb_data_only = openpyxl.load_workbook('writeFormula.xlsx', data_only=True)
sheet = wb_data_only.active
print(sheet['A3'].value)


print("==========================12.9.3")
print("==========================12.9.4")
print("==========================12.9.5")
print("==========================12.9.6")
print("==========================12.9.7")
print("==========================12.9.8")
print("==========================12.9.9")
print("==========================12.9.10")
print("==========================12.9.11")

