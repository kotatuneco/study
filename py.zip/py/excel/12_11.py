print("==========================12.11.1")
import openpyxl

wb = openpyxl.Workbook()
print( wb.get_sheet_names() )
sheet = wb.active
for i in range(1,11):
    sheet['A' + str(i)] = i

ref_obj = openpyxl.chart.Reference(sheet, min_col=1, min_row=1, max_col=10, max_row=10)
series_obj = openpyxl.chart.Series(ref_obj, title='First series')
chart_obj = openpyxl.chart.BarChart()
chart_obj.append(series_obj)
# chart_obj.add_data(ref_obj)
# chart_obj.y = 50    # 位置を設定
# chart_obj.x = 100   # 位置を設定
# chart_obj.w = 300   # サイズを設定
# chart_obj.h = 200   # サイズを設定
sheet.add_chart(chart_obj, "E15")
wb.save('sampleChart_5.xlsx')


print("==========================12.11.2")
# import openpyxl

# wb_formulas = openpyxl.load_workbook('writeFormula.xlsx')
# sheet = wb_formulas.active
# print(sheet['A3'].value)

# wb_data_only = openpyxl.load_workbook('writeFormula.xlsx', data_only=True)
# sheet = wb_data_only.active
# print(sheet['A3'].value)


print("==========================12.11.3")
print("==========================12.11.4")
print("==========================12.11.5")
print("==========================12.11.6")
print("==========================12.11.7")
print("==========================12.11.8")
print("==========================12.11.9")
print("==========================12.11.10")
print("==========================12.11.11")

