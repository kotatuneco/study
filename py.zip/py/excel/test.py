import census2010
print( census2010.all_data['AK']['Anchorage'] )
anchorage_pop = census2010.all_data['AK']['Anchorage']['pop']
print('2010年のアンカレッジの人口は' + str(anchorage_pop) + 'です')
