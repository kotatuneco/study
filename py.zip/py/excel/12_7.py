print("==========================12.9.1")
import openpyxl

wb = openpyxl.Workbook()
print( wb.get_sheet_names() )
sheet = wb.active
sheet['A1'] = 200
sheet['A2'] = 300
sheet['A3'] = '=SUM(A1:A2)'
wb.save('writeFormula.xlsx')


print("==========================12.9.2")
# import openpyxl

# wb = openpyxl.Workbook()
# print( wb.get_sheet_names() )
# wb.create_sheet()
# print( wb.get_sheet_names() )
# wb.create_sheet(index=0, title='First Sheet')
# print( wb.get_sheet_names() )
# wb.create_sheet(index=2, title='Middle Sheet')
# print( wb.get_sheet_names() )
# wb.remove_sheet(wb.get_sheet_by_name('Middle Sheet'))
# wb.remove_sheet(wb.get_sheet_by_name('Sheet1'))
# print( wb.get_sheet_names() )

print("==========================12.9.3")

# sheet = wb.get_sheet_by_name('Sheet')
# sheet['A1'] = 'Hello world!'
# print(sheet['A1'].value)
# sheet['A2'] = 0
# sheet['A3'] = 1
# sheet['A4'] = 2
# sheet['A5'] = 3
# sheet['A6'] = 4.0
# sheet['A7'] = 5.1
# sheet['A8'] = 6.2
# sheet['A9'] = 7.3
# sheet['A10'] = 8.4
# sheet['A11'] = 9.5

# sheet['A12'] = '=SUM(A2:A11)'
# sheet['A13'] = '=MAX(A2:A11)'
# # sheet.cell(row=2,column=14).value = '=MAX(A1:A10)'    # <=実行されない?なぜ？？

# wb.save('hello_4.xlsx')


print("==========================12.9.4")
print("==========================12.9.5")
print("==========================12.9.6")
print("==========================12.9.7")
print("==========================12.9.8")
print("==========================12.9.9")
print("==========================12.9.10")
print("==========================12.9.11")

