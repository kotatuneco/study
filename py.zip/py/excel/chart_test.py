print("==========================0")

# from openpyxl import Workbook
# wb = Workbook()
# ws = wb.active
# for i in range(10):
#     ws.append([i])
 
# from openpyxl.chart import BarChart, Reference, Series
# values = Reference(ws, min_col=1, min_row=1, max_col=1, max_row=10)
# chart = BarChart()
# chart.add_data(values)
# ws.add_chart(chart, "E15")
# wb.save("SampleChart_1.xlsx")

print("==========================1")
from openpyxl import Workbook
wb = Workbook()
ws = wb.active
for i in range(1,11):
    ws['A' + str(i)] = i
 
from openpyxl.chart import LineChart, Reference, Series
values = Reference(ws, min_col=1, min_row=1, max_col=1, max_row=10)
chart = LineChart()
chart.add_data(values)
ws.add_chart(chart, "E15")
wb.save("chart_1.xlsx")

print("==========================2")
from openpyxl import Workbook
wb = Workbook()
ws = wb.active
for i in range(1,11):
    ws['A' + str(i)] = i
 
from openpyxl.chart import LineChart, Reference, Series
values = Reference(ws, min_col=1, min_row=1, max_col=1, max_row=10)
chart = LineChart()
chart.title = "棒グラフ"
chart.y_axis.title = 'Test number'
chart.x_axis.title = 'Sample length'
chart.add_data(values)
ws.add_chart(chart, "E15")
wb.save("chart_2.xlsx")

print("==========================3")
print("==========================4")
print("==========================5")
print("==========================6")
print("==========================7")
print("==========================8")
print("==========================9")
print("==========================10")
