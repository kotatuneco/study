import os,csv

### csv情報をcsvA,csvBにセットする - ここから
class CaCsv:
    def __init__(self, fname, tag, c_level, c_lv):
        self.str_filename = fname
        self.str_tag = tag  # "White"
        self.colum_level = c_level
        self.colum_lv = c_lv
        self.str_label_x = ""
        self.str_label_y = ""
        self.lstr_level : List[str] = []
        self.lstr_lv : List[str] = []
        self.lfl_level : List[float] = []
        self.lfl_lv : List[float] = []
        self.lfl_lv_Normalize : List[float] = []

    def add_lstr_level(self,msg):
        self.lstr_level.append(msg)

    def cal_lv_normalize(self):
        for value in self.lfl_lv:
            self.lfl_lv_Normalize.append( value / self.lfl_lv[-1] )

    def read_csv(self):
        for csvTmp in [self]:
            # work area初期化
            chk_flag = False
            label_flag = False
            with open( csvTmp.str_filename ) as f:
                reader = csv.reader(f)
                for row in reader:
                    # 処理データ
                    if chk_flag:
                        # syorisuru
                        if label_flag == False:
                            csvTmp.str_label_x = row[csvTmp.colum_level]
                            csvTmp.str_label_y = row[csvTmp.colum_lv]
                            label_flag = True
                        else:
                            csvTmp.lstr_level.append(row[csvTmp.colum_level])
                            csvTmp.lstr_lv.append(row[csvTmp.colum_lv])
                            csvTmp.lfl_level.append( float(row[csvTmp.colum_level]) )
                            csvTmp.lfl_lv.append( float(row[csvTmp.colum_lv]) )
                            # print(row)
                    # 処理必要？
                    if csvTmp.str_tag in row:
                        print("!!!white!!!")
                        chk_flag = True
                    # print(row)

            # 正規化したデータをセットする
            csvTmp.cal_lv_normalize()
            # for value in csvTmp.lfl_lv:
            #     csvTmp.lfl_lv_Normalize.append( value / csvTmp.lfl_lv[-1] )
            
            # データの確認
            # print( csvTmp.lstr_level )
            # print( csvTmp.lstr_lv )
            # print( csvTmp.lfl_level )
            # print( csvTmp.lfl_lv )
            # print( csvTmp.lfl_lv_Normalize )

            ### csv情報をcsvA,csvBにセットする - ここまで
