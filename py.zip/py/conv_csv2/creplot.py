### plotの生成 - ここから
import numpy as np
import matplotlib
matplotlib.use('Agg') # -----(1)
import matplotlib.pyplot as plt

# PdfPagesのインポート
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt

### グラフの生成 - ここから
## ほしいグラフは？？？
## [0, 0] - AとB, x:level, y:Lv, 正規化
## [0, 1] - AとB, x:level, y:Lv, 生データ
## [1, 0] - AとB, x:level, y:Lv, 正規化(0-16)
## [1, 1] - AとB, x:level, y:Lv, 生データ(0-16)


### csv情報をcsvA,csvBにセットする - ここから
class CrePlot:
    def __init__(self):
        pass

    def write_png( self,                           \
                   outfilename,                    \
                   csvA_str_filename,              \
                   csvB_str_filename,              \
                   l_ax1_csvA_x, l_ax1_csvA_y,     \
                   l_ax1_csvB_x, l_ax1_csvB_y,     \
                   l_ax2_csvA_x, l_ax2_csvA_y,     \
                   l_ax2_csvB_x, l_ax2_csvB_y):
        # figure
        fig = plt.figure()
        ax_1 = fig.add_subplot(2, 1, 1)     #2行1列の1番目
        ax_2 = fig.add_subplot(2, 1, 2)     #2行1列の2番目

        # plot
        ax_1.plot(l_ax1_csvA_x, l_ax1_csvA_y, linestyle='--', color='b', marker="h", label=(csvA_str_filename +' x:Level, y:Normalize Lv') )
        ax_1.plot(l_ax1_csvB_x, l_ax1_csvB_y, linestyle='-', color='#e46409', marker="h", label=(csvB_str_filename +' x:Level, y:Normalize Lv') )
        ax_2.plot(l_ax2_csvA_x, l_ax2_csvA_y, linestyle='--', color='b', marker="h", label=(csvA_str_filename +' x:Level, y:Normalize Lv') )
        ax_2.plot(l_ax2_csvB_x, l_ax2_csvB_y, linestyle='-', color='#e46409', marker="h", label=(csvB_str_filename +' x:Level, y:Normalize Lv') )
        # ax_1.plot(csvA.lfl_level, csvA.lfl_lv_Normalize, linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
        # ax_1.plot(csvB.lfl_level, csvB.lfl_lv_Normalize, linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )
        # ax_2.plot(csvA.lfl_level[:4], csvA.lfl_lv_Normalize[:4], linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
        # ax_2.plot(csvB.lfl_level[:4], csvB.lfl_lv_Normalize[:4], linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )

        # x axis
        # plt.xlim([ csvA.lfl_level[0], csvA.lfl_level[-1] ])
        ax_1.set_xticks( l_ax1_csvA_x )
        # ax_1.set_xticklabels( csvA.lstr_level ) <=ここ
        ax_1.set_xlabel('x')
        ax_2.set_xticks( l_ax2_csvA_x )
        # ax_2.set_xticklabels( csvA.lstr_level[:4] ) <=ここ
        ax_2.set_xlabel('x')
        # ax_1.set_xticks( csvA.lfl_level )
        # ax_1.set_xticklabels( csvA.lstr_level )
        # ax_1.set_xlabel('x')
        # ax_2.set_xticks( csvA.lfl_level[:4] )
        # ax_2.set_xticklabels( csvA.lstr_level[:4] )
        # ax_2.set_xlabel('x')

        # y axis
        # plt.ylim([ csvA.lfl_lv_Normalize[0], csvA.lfl_lv_Normalize[-1] ])
        ax_1.set_yticks( l_ax1_csvA_y )
        ax_1.set_ylabel('y')
        ax_2.set_yticks( l_ax2_csvA_y )
        ax_2.set_ylabel('y')

        # legend and title
        # ax_1.legend(loc='best')
        ax_1.legend(loc='upper left')
        # ax_1.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )
        ax_1.set_title( ("Lv All") )
        # ax_2.legend(loc='best')
        ax_2.legend(loc='upper left')
        ax_2.set_title( ("Lv -64") )
        # ax_2.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )

        # save as png
        plt.savefig( outfilename ) # -----(2)

    def write_pdf( self,                           \
                   outfilename,                    ):
        # pdfファイルの初期化
        pp = PdfPages(outfilename)

        # figureをセーブする
        pp.savefig()

        # pdfファイルをクローズする。
        pp.close()

### グラフの生成 - ここまで


