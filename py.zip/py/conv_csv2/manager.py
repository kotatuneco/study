from cacsv import *
from crexlsx import *
from creplot import *
import sys
import os,csv

class Manager:
    def __init__( self):
        # args = sys.argv
        args = ["csv2png.py", "sampleA.csv", "sampleB.csv", "White", "0", "4"]
        self.csvA = CaCsv(args[1], args[3], int(args[4]), int(args[5]) )  # args[1] : ***.csv , args[3] : 'White'
        self.csvB = CaCsv(args[2], args[3], int(args[4]), int(args[5]) )  # args[2] : ***.csv , args[3] : 'White'
        self.plot = CrePlot()
        self.xlsx = CreXlsx(10, 11) #10 : label, 11 : データ開始位置

    def read_cacsv( self):
        self.csvA.read_csv()
        self.csvB.read_csv()

    def write_plot_png( self, outfname):
        self.plot.write_png(    outfname,                                                \
                                self.csvA.str_filename,                                  \
                                self.csvB.str_filename,                                  \
                                self.csvA.lfl_level, self.csvA.lfl_lv_Normalize,         \
                                self.csvB.lfl_level, self.csvB.lfl_lv_Normalize,         \
                                self.csvA.lfl_level[:4], self.csvA.lfl_lv_Normalize[:4], \
                                self.csvB.lfl_level[:4], self.csvB.lfl_lv_Normalize[:4]  \
                            )

    def write_plot_pdf( self, outfname):
        self.plot.write_pdf( outfname )

    def write_xlsx_header( self):
        self.xlsx.write_header()

    def write_xlsx_data( self, csvA, csvB):
        self.xlsx.write_data(csvA, csvB)

    def write_xlsx_chart( self):
        self.xlsx.write_chart()

    def save_xlsx( self, outfname):
        self.xlsx.save_xlsx(outfname)

# managerの作成, 引数処理
mng = Manager()

# csvファイルの読み込み
mng.read_cacsv()

# グラフの生成
if True:
    # png生成
    mng.write_plot_png('test.png')
    # pdf生成
    mng.write_plot_pdf('test.pdf')

# エクセルファイルの生成
if True:
    # 書き込み - header
    mng.write_xlsx_header()
    # 書き込み - data
    mng.write_xlsx_data( mng.csvA, mng.csvB )
    # 書き込み - chart
    mng.write_xlsx_chart()
    # ブックの保存
    mng.save_xlsx('test.xlsx')
