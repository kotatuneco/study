### エクセルファイルの生成 - ここから
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl import Workbook

### csv情報をcsvA,csvBにセットする - ここから
class CreXlsx:
    def __init__(self, base_row, data_row):
        # Excelファイルを開きます
        self.wb = Workbook()
        self.ws = self.wb.active
        # sheetNames = self.wb.sheetnames
        # self.ws = self.wb[sheetNames[0]]  # ここでは例として1つ目のシートを取得しています
        # データをセットする
        self.base_row = base_row    # 10
        self.data_row = data_row    # 11

    def create_sheet(self, sheet_name, index):
        pass

    def write_header(self):
        self.ws['A' + str(self.base_row)] = 'level'
        self.ws['B' + str(self.base_row)] = 'Lv'
        self.ws['C' + str(self.base_row)] = 'Lv_Nom'
        self.ws['D' + str(self.base_row)] = 'level'
        self.ws['E' + str(self.base_row)] = 'Lv'
        self.ws['F' + str(self.base_row)] = 'Lv_Nom'

    def write_data(self, csvA, csvB):
        count = self.data_row
        for level, lv, lv_Normalize in zip(csvA.lfl_level, csvA.lfl_lv, csvA.lfl_lv_Normalize):
            self.ws['A' + str(count)] = level
            self.ws['B' + str(count)] = lv
            self.ws['C' + str(count)] = lv_Normalize
            count += 1

        count = self.data_row
        for level, lv, lv_Normalize in zip(csvB.lfl_level, csvB.lfl_lv, csvB.lfl_lv_Normalize):
            self.ws['D' + str(count)] = level
            self.ws['E' + str(count)] = lv
            self.ws['F' + str(count)] = lv_Normalize
            count += 1

    def write_chart(self):
        # 出力するグラフのサイズ
        chtWidth = 24
        chtHeight = 12

        # 1つ目の散布図を用意します
        cht1 = openpyxl.chart.ScatterChart()
        cht1.title = '3120-2460 Lv正規化'
        cht1.x_axis.title = 'Level'
        cht1.y_axis.axId = 200
        cht1.y_axis.title = 'Lv'
        cht1.height = chtHeight
        cht1.width = chtWidth

        # 2つ目の散布図を用意します
        cht2 = openpyxl.chart.ScatterChart()
        cht2.title = '3120-2460 Lv64以下'
        cht2.x_axis.title = 'Level'
        cht2.y_axis.title = "Lv"
        cht2.y_axis.majorGridLines = None
        cht2.height = chtHeight
        cht2.width = chtWidth

        # グラフ化するデータを参照する
        cht1_startRow = self.data_row
        cht1_endRow = self.data_row + 10
        cht2_startRow = self.data_row
        cht2_endRow = self.data_row + 4

        # Excelのデータ参照した変数を用意する
        cht1_levelValues = openpyxl.chart.Reference(self.ws, min_col=1, min_row=cht1_startRow, max_row=cht1_endRow)
        cht1_left_LvNormalize = openpyxl.chart.Reference(self.ws, min_col=3, min_row=cht1_startRow, max_row=cht1_endRow)
        cht1_right_LvNormalize = openpyxl.chart.Reference(self.ws, min_col=6, min_row=cht1_startRow, max_row=cht1_endRow)
        cht2_levelValues = openpyxl.chart.Reference(self.ws, min_col=1, min_row=cht2_startRow, max_row=cht2_endRow)
        cht2_left_LvNormalize = openpyxl.chart.Reference(self.ws, min_col=3, min_row=cht2_startRow, max_row=cht2_endRow)
        cht2_right_LvNormalize = openpyxl.chart.Reference(self.ws, min_col=6, min_row=cht2_startRow, max_row=cht2_endRow)

        # 系列を用意し、データ参照を入力する 最初の行を凡例とする
        cht1_left_s1 = openpyxl.chart.Series(cht1_left_LvNormalize, cht1_levelValues, title_from_data=False, title='3120')
        cht1_right_s2 = openpyxl.chart.Series(cht1_right_LvNormalize, cht1_levelValues, title_from_data=False, title='2460')
        cht2_left_s1 = openpyxl.chart.Series(cht2_left_LvNormalize, cht2_levelValues, title_from_data=False, title='3120')
        cht2_right_s2 = openpyxl.chart.Series(cht2_right_LvNormalize, cht2_levelValues, title_from_data=False, title='2460')

        # グラフの書式設定をする
        cht1_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
        cht1_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
        cht1_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
        cht1_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

        cht1_right_s2.graphicalProperties.line.solidFill = "c0504d"
        cht1_right_s2.marker.symbol = "x"
        cht1_right_s2.marker.graphicalProperties.solidFill = "c0504d"
        cht1_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"

        cht2_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
        cht2_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
        cht2_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
        cht2_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

        cht2_right_s2.graphicalProperties.line.solidFill = "c0504d"
        cht2_right_s2.marker.symbol = "x"
        cht2_right_s2.marker.graphicalProperties.solidFill = "c0504d"
        cht2_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"

        # Chartに系列を追加する
        # 1つ目のグラフに系列(s1,s2)を、2つ目のグラフに2つの系列(s3, s4)を追加している。
        cht1.series.append(cht1_left_s1)
        cht1.series.append(cht1_right_s2)
        cht2.series.append(cht2_left_s1)
        cht2.series.append(cht2_right_s2)

        # y軸を2軸もつグラフに設定する(グラフを足し合わせる)
        # 2つ目のグラフのy軸を右側に設定する
        cht2.y_axis.crosses = "max"

        # Excelシートにグラフを貼り付ける
        graphInsertCol = 12 # グラフを挿入する列番号
        inColLetter = get_column_letter(graphInsertCol)
        inRow = 2 # グラフを挿入する行番号
        inCellLetter = inColLetter + str(inRow) # グラフを挿入するセルの位置をExcel形式で作る
        self.ws.add_chart(cht1, inCellLetter)
        inCellLetter = inColLetter + str(30) # グラフを挿入するセルの位置をExcel形式で作る
        self.ws.add_chart(cht2, inCellLetter)

    def save_xlsx(self, outfilename):
        # outfilename = csvA.str_filename + "_" + csvB.str_filename + ".xlsx"
        # outfilename = outfilename.replace('.csv', '')
        self.wb.save( outfilename )

### エクセルファイルの生成 - ここまで

