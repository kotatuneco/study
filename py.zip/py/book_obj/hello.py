# 関数の定義

def test():
    return 1

print('call test:{}'.format(test()))
# call test:1

print('type test:{}' .format(type(test)))
# call test:<class 'function'>

# 関数を変数に代入
test2 = test

print('call test2:{}'.format(test2()))
# call test2:1

print('type test2:{}' .format(type(test2)))
# call test:<class 'function'>

### 関数渡し
print('')
print('関数渡し')

# 関数を呼び出す関数(高階関数)
def fun1(fun, text):
    fun(text)

# 呼び出される普通の関数
def fun2(text):
    print('fun2:' + text)

# 高階関数に関数を渡して利用
fun1(fun2, 'hello')
# fun2: hello

### 電卓
print('')
print('電卓')

# フレームワーク(手を加えない)
class Calc:
    # 初期化でカスタマイズ用の関数定義を受取登録
    def __init__(self, operation_list):
        self.operation_dict = {}
        for operation_tuple in operation_list:
            (operation, method) = operation_tuple
            self.operation_dict[operation] = method

    # イベントドリブンで電卓として動く
    def run(self):
        while True:
            print('please input your calculation')
            input_text = input()
            words = input_text.split()
            if words[0] == 'exit':
                return
            if len(words) < 3:
                continue
            if words[0] not in self.operation_dict:
                continue
            
            # カスタマイズされた関数を呼び出す
            fun = self.operation_dict[words[0]]
            print(fun(int(words[1]), int(words[2])))

def add(a, b):
    return a + b

def decrease(a, b):
    return a - b

if False:
    calc = Calc([("plus", add), ("minus", decrease)])
    calc.run()

### カウンター
print('')
print('カウンター')

import tkinter

if False:
    counter = 0
    font = ("Helevetica", 32, "bold")
    button = tkinter.Button( font = font, text = str( counter))

    #処理 を 作成( カウンター の 数字 を 増やす)
    def clicked():
        global counter, button
        counter = counter + 1
        button.config(text=str(counter))

    # GUIのライブラリに処理を登録
    button.config(command=clicked)
    button.pack()
    button.mainloop()


#関数 を 作る 関数 　 クロージャ
def adder( x):
    #クロージャ が 返す 関数
    def fun( y):
        # x は クロージャ の 引数、 y は 作成 さ れる 関数 の 引数 
        return x + y
    # 作成した関数を返す
    return fun

adder5 = adder(5)
print(adder5(10))
# 15

adder7 = adder(7)
print(adder7(10))
# 17

# クロージャーはあまりつかわない

### ラムダ式
print('')
print('ラムダ式')

# lambda 式 は「 lambda 引数: 式」 という 形 で 関数 を 書く と、 その 関数 を オブジェクト として 返し ます。 
# def による 関数 の 宣言 と 異なり、 関数 名 が ない こと が わかり ます。 
# その ため「 無名 関数」 と 呼ば れ て いる の です。 実際 に 利用 し て み ます。

my_print = lambda x : print(' my_print : {}'.format(x))
my_print('hello')
# my_print : hello
print(my_print)
# <function <lambda> at 0x000001CE49A199D8>

adder_lambda = lambda x, y : x + y
print(adder_lambda(2,3))

funcs = [(lambda x, y: x + y), (lambda x, y: x-y), (lambda x, y: x*y),( lambda x, y: x**y)]
for fun in funcs:
    print( fun( 5, 10))


### リスト内包表記
print('')
print('リスト内包表記')


list_ = [x*2 for x in range(10)]
print(list_)

list_2 = [x*2 for x in range(10) if x%2 == 0]
print(list_2 )


### ポリモーフィズム
print('')
print('ポリモーフィズム')

# 呼び出さ れる メソッド は 親 クラス で 実装 する
# 共通 し た 処理 は 親 クラス に 任せる
# 子 クラス は 親 クラス との 差分 のみ 実装 する

class Graphic:
    def __init__(self, x1, y1, x2, y2):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
    
    def draw(self):
        print('Error')
    
rectangle = '''({},{})
#######
##   ##
##   ##
#######
 ({},{})'''

class Rectangle(Graphic):
    def draw(self):
        print(rectangle.format(self.x1,self.y1,self.x2,self.y2))

triangle = '''({},{})
  ###
 #   #
#     #
#######
 ({},{})'''


class Triangle(Graphic):
    def draw(self):
        print(triangle.format(self.x1,self.y1,self.x2,self.y2))


# (1) どの 図形、 座標 と する か 
# graphic_type = 'rectangle'
graphic_type = 'triangle'

x1,y1,x2,y2 = 1,2,3,4

# (2) 入力 さ れ た 図形 に 応じ て 子 クラス の インスタンス を 作成
if( graphic_type == 'rectangle'):
    graphic = Rectangle( x1,y1,x2,y2)
elif( graphic_type == 'triangle'):
    graphic = Triangle( x1,y1,x2,y2)
else:
    graphic = Graphic( x1,y1,x2,y2)
# (3) オーバーライド さ れ た 親 クラス も 持つ メソッド の 呼び出し 
graphic.draw()



### hello tkinter
import tkinter as tk
print('')
print('hello tkinter')

if False:
    import tkinter as tk

    font =('Helevetica', 32, 'bold')
    label = tk.Label( text ='Hello Tkinter', font = font, bg ='red')
    label.pack()            # ラベルを配置
    label.mainloop()


### tkinter 2label
print('')
print('tkinter 2label')

if False:
    import tkinter as tk

    frame = tk.Frame()
    font =('Helevetica', 32, 'bold')
    label1 = tk.Label(frame, text ='Hello Tkinter', font = font, bg ='red')
    label2 = tk.Label(frame, text ='Hello Python', font = font, bg ='blue')
    # label1.pack()
    # label2.pack()
    # label1.pack(fill=tk.X)
    # label2.pack(fill=tk.X)
    label1.pack(side=tk.LEFT)
    label2.pack(side=tk.RIGHT)
    frame.pack()
    frame.mainloop()

### tkinter 3label
print('')
print('tkinter 3label')

if False:
    import tkinter as tk

    frame1 = tk.Frame()

    frame2 = tk.Frame(frame1)   # frame2の親にframe1を指定
    font =('Helevetica', 32, 'bold')
    label1 = tk.Label(frame2, text ='Hello Tkinter', font = font, bg ='red')
    label2 = tk.Label(frame2, text ='Hello Python', font = font, bg ='blue')
    label1.pack(side=tk.LEFT)
    label2.pack(side=tk.RIGHT)
    frame2.pack()

    # child2
    label3 = tk.Label(frame1, text ='Hello Python', font = font, bg ='green')
    label3.pack(fill=tk.X)

    frame1.pack()
    frame1.mainloop()


### tkinter counter
print('')
print('tkinter counter')

class Counter(tk.Frame):
    def __init__(self, master=None, value = 0):
        self.value = value
        tk.Frame.__init__(self, master)
        font =('Helevetica', 32, 'bold')
        self.label = tk.Label(self, text=self.getText(), font=font, bg='red')
        self.button = tk.Button(self, text='Click', command=self.clicked)
        self.label.pack()
        self.button.pack()
    
    def clicked(self):
        self.value += 1
        self.label.configure(text=self.getText())

    def getText(self):
        return 'Count:{}'.format(self.value)

f = tk.Frame()
c1 = Counter(value=0, master=f)
c2 = Counter(value=5, master=f)
c1.pack()
c2.pack()
f.pack()
f.mainloop()

### try catch
print('')
print('try catch')

if False:
    print(' 1: outside of try/ catch')
    try:
        print(' 2: inside of try scope')
        5 / 0
        print(' 3: inside of try scope')
    except Exception:
        print(' 4: inside of except( catch) scope')
    print(' 5: outside of try/ catch')


if True:
    print( 1)
    try:
        5/ 0
    except Exception as e:
        print( type( e))
        print( e)
    print( 2)

try:
    a = 0
    if a == 0:
        raise Exception('hello')
    5 / a
except Exception as e:
    print( type( e))
    print( e)

