import os

for foldername, subfolders, filenames in os.walk( os.getcwd() ):
    print('the current folder is ' + foldername)

    for subfolder in subfolders:
        print( 'subfolder of ' + foldername + ':' + subfolder )
    
    for filename in filenames:
        print( 'file inside ' + foldername + ':' + filename )

    print('')

# # shutil.copy('sample.csv', 'sample_copy.csv')

# # shutil.copytree('0', '0_bak')

# # shutil.copytree('.', '.\\all')

# # shutil.move('sample.csv', 'sample_rename.csv')
# # shutil.move('sample_rename.csv', 'sample.csv')

# for filename in os.listdir( os.getcwd() ):
#     print( filename )
#     if 'figure' in filename:
#         dst = filename.replace('figure', 'しがらみあしをとる')
#         print( dst )
#         shutil.copy(filename, dst)
# # src = 'I like orange.'
# # dst = src.replace('orange', 'apple') # 'I like apple.'