import os

print( os.path.join('usr', 'bin', 'spam') )

my_files = ['acounts.txt', 'details.csv', 'invite.docx']

for filename in my_files:
    print(os.path.join('c:\\Users\\asweigart', filename))

path_plot = os.getcwd()
print(path_plot)
os.chdir('c:\\Windows\\System32')
print(os.getcwd())
os.chdir(path_plot)
print(os.getcwd())

# os.makedirs('D:\\md\\py\\plot\\0\\1\\2\\3')

print( os.path.abspath('.') )
print( os.path.abspath('.\\0') )
print( os.path.isabs('.') )
print( os.path.isabs( os.path.abspath('.') ) )

print( "=========kugiri=========0" )
for filename in os.listdir( os.getcwd() ):
    print( filename )
print( "=========kugiri=========1" )

path = os.path.join(os.getcwd(), 'sample.csv')
print( os.path.exists(path) )
print( os.path.isdir(path) )
print( os.path.isfile(path) )

print( "=========kugiri=========2" )

