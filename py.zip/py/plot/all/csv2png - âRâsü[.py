class Spam:
    val = 100
    str_filename = ""
    lstr_level = []
    lstr_lv = []
    lfl_level = []
    lfl_lv = []
    lfl_lv_Normalize = []

    def ham(self):
        self.egg('call method')

    def egg(self,msg):
        print("{0}".format(msg))
        print(("{0}".format(self.val)))

import sys

args = sys.argv

print(args)
print("第1引数：" + args[1])
print("第2引数：" + args[2])
print("第3引数：" + args[3])

# str_file_a = 

spam = Spam()
spam.ham()

print( spam.val )

spam.str_filename = "abcdef"

print( spam.str_filename )


csvA = Spam()
csvB = Spam()

csvA.str_filename = args[1]
print( csvA.str_filename )
csvB.str_filename = args[2]
print( csvB.str_filename )

