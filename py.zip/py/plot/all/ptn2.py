import matplotlib.pyplot as plt

x = [100, 200, 300, 400, 500, 600]
y1 = [10, 20, 30, 50, 80, 130]
y2 = [10, 15, 30, 45, 60, 75]
y3 = [10, 15, 30, 45, 60, 180]

fig = plt.figure()

# 1行3列に分割した中の1(左側)
ax1 = fig.add_subplot(1, 3, 1)
ax1.plot(x, y1, marker="o", color = "red", linestyle = "--")

# 1行3列に分割した中の2(右側)
ax2 = fig.add_subplot(1, 3, 2)
ax2.plot(x, y2, marker="v", color = "blue", linestyle = ":")

# 1行3列に分割した中の2(右側)
ax3 = fig.add_subplot(1, 3, 3)
ax3.plot(x, y3, marker="v", color = "green", linestyle = ":")

# 2行3列に分割した中の2(右側)
ax4 = fig.add_subplot(2, 3, 1)
ax4.plot(x, y3, marker="v", color = "green", linestyle = ":")

plt.show()

