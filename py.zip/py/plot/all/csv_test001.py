import os,csv
# with open('sample2.csv') as f:
#     reader = csv.reader(f)
#     for row in reader:
#         print(row)

str_tag = "White"
ref_x = 0
ref_y = 4
chk_flag = False
label_flag = False
str_label_x = ""
str_label_y = ""
l_x = []
l_y = []

with open('sample2.csv') as f:
    reader = csv.reader(f)
    for row in reader:
        # 処理データ
        if chk_flag:
            # syorisuru
            if label_flag == False:
                str_label_x = row[ref_x]
                str_label_y = row[ref_y]
                label_flag = True
            else:
                l_x.append(row[ref_x])
                l_y.append(row[ref_y])
                # print(row)
        # 処理必要？
        if str_tag in row:
            print("!!!white!!!")
            chk_flag = True
        # print(row)

print(chk_flag)
print(label_flag)
print(str_label_x)
print(str_label_y)
print(l_x)
print(l_y)







l = ['oneXXXaaa', 'twoXXXbbb', 'three999aaa', '000111222']

l_in = [s for s in l if 'White' in s]
print(l_in)

# l_in = [s for s in l if 'XXX' in s]
# print(l_in)
# ['oneXXXaaa', 'twoXXXbbb']

l_in_not = [s for s in l if 'XXX' not in s]
print(l_in_not)
# ['three999aaa', '000111222']