import matplotlib.pyplot as plt

a0 = [1,2,3,4,5]
a1 = [3.5,3.2,0.7,2,1]
b0 = [1,2,3,4,5]
b1 = [1.2,1.1,0.5,0.1,0.2]

plt.plot(a0, a1)
plt.bar(b0, b1)

# 描画実行
plt.show()
