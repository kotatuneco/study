# 特定の文字列を置換する

import shutil, os

shutil.copy('sample.csv', 'sample_copy.csv')

# shutil.copytree('0', '0_bak')

shutil.copytree('.', '.\\all')

