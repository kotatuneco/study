# 特定の文字列を置換する

import shutil, os

# shutil.copy('sample.csv', 'sample_copy.csv')

# shutil.copytree('0', '0_bak')

# shutil.copytree('.', '.\\all')

# shutil.move('sample.csv', 'sample_rename.csv')
# shutil.move('sample_rename.csv', 'sample.csv')

for filename in os.listdir( os.getcwd() ):
    print( filename )
    if 'figure' in filename:
        dst = filename.replace('figure', 'しがらみあしをとる')
        print( dst )
        shutil.copy(filename, dst)
# src = 'I like orange.'
# dst = src.replace('orange', 'apple') # 'I like apple.'