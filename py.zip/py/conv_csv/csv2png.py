### csv情報をcsvA,csvBにセットする - ここから

class CsvCtl:
    val = 100
    str_filename = ""

    str_tag = "White"
    row_level = 0
    row_lv = 4

    str_label_x = ""
    str_label_y = ""

    def __init__(self):
        self.lstr_level : List[str] = []
        self.lstr_lv : List[str] = []
        self.lfl_level : List[float] = []
        self.lfl_lv : List[float] = []
        self.lfl_lv_Normalize : List[float] = []

    def add_lstr_level(self,msg):
        self.lstr_level.append(msg)

import sys
import os,csv

# args = sys.argv
args = ["csv2png.py", "sampleA.csv", "sampleB.csv", "White", "0", "4"]

csvA = CsvCtl()
csvB = CsvCtl()

# 引数ケア - ここから
csvA.str_filename = args[1]
print( csvA.str_filename )
csvB.str_filename = args[2]
print( csvB.str_filename )
csvA.str_tag = args[3]  # "White"
csvA.row_level = int( args[4] )
csvA.row_lv = int( args[5] )
csvB.str_tag = args[3]
csvB.row_level = int( args[4] )
csvB.row_lv = int( args[5] )
# 引数ケア - ここまで

for csvTmp in [csvA, csvB]:
    # work area初期化
    chk_flag = False
    label_flag = False
    with open( csvTmp.str_filename ) as f:
        reader = csv.reader(f)
        for row in reader:
            # 処理データ
            if chk_flag:
                # syorisuru
                if label_flag == False:
                    csvTmp.str_label_x = row[csvTmp.row_level]
                    csvTmp.str_label_y = row[csvTmp.row_lv]
                    label_flag = True
                else:
                    csvTmp.lstr_level.append(row[csvTmp.row_level])
                    csvTmp.lstr_lv.append(row[csvTmp.row_lv])
                    csvTmp.lfl_level.append( float(row[csvTmp.row_level]) )
                    csvTmp.lfl_lv.append( float(row[csvTmp.row_lv]) )
                    # print(row)
            # 処理必要？
            if csvTmp.str_tag in row:
                print("!!!white!!!")
                chk_flag = True
            # print(row)

    # 正規化したデータをセットする
    for value in csvTmp.lfl_lv:
        csvTmp.lfl_lv_Normalize.append( value / csvTmp.lfl_lv[-1] )
    
    # データの確認
    # print( csvTmp.lstr_level )
    # print( csvTmp.lstr_lv )
    # print( csvTmp.lfl_level )
    # print( csvTmp.lfl_lv )
    # print( csvTmp.lfl_lv_Normalize )

### csv情報をcsvA,csvBにセットする - ここまで


### グラフの生成 - ここから
## ほしいグラフは？？？
## [0, 0] - AとB, x:level, y:Lv, 正規化
## [0, 1] - AとB, x:level, y:Lv, 生データ
## [1, 0] - AとB, x:level, y:Lv, 正規化(0-16)
## [1, 1] - AとB, x:level, y:Lv, 生データ(0-16)

import numpy as np
import matplotlib
matplotlib.use('Agg') # -----(1)
import matplotlib.pyplot as plt


# figure
fig = plt.figure()
# ax_1 = fig.add_subplot(1, 2, 1)     #1行2列の1番目
# ax_2 = fig.add_subplot(1, 2, 2)     #1行2列の2番目
ax_1 = fig.add_subplot(2, 1, 1)     #2行1列の1番目
ax_2 = fig.add_subplot(2, 1, 2)     #2行1列の2番目

# plot
ax_1.plot(csvA.lfl_level, csvA.lfl_lv_Normalize, linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
ax_1.plot(csvB.lfl_level, csvB.lfl_lv_Normalize, linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )
ax_2.plot(csvA.lfl_level[:4], csvA.lfl_lv_Normalize[:4], linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
ax_2.plot(csvB.lfl_level[:4], csvB.lfl_lv_Normalize[:4], linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )

# x axis
# plt.xlim([ csvA.lfl_level[0], csvA.lfl_level[-1] ])
ax_1.set_xticks( csvA.lfl_level )
ax_1.set_xticklabels( csvA.lstr_level )
ax_1.set_xlabel('x')
ax_2.set_xticks( csvA.lfl_level[:4] )
ax_2.set_xticklabels( csvA.lstr_level[:4] )
ax_2.set_xlabel('x')

# y axis
# plt.ylim([ csvA.lfl_lv_Normalize[0], csvA.lfl_lv_Normalize[-1] ])
ax_1.set_yticks( csvA.lfl_lv_Normalize )
ax_1.set_ylabel('y')
ax_2.set_yticks( csvA.lfl_lv_Normalize[:4] )
ax_2.set_ylabel('y')

# legend and title
# ax_1.legend(loc='best')
ax_1.legend(loc='upper left')
# ax_1.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )
ax_1.set_title( ("Lv All") )
# ax_2.legend(loc='best')
ax_2.legend(loc='upper left')
ax_2.set_title( ("Lv -64") )
# ax_2.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )

# save as png
plt.savefig( (csvA.str_filename + "_" + csvB.str_filename + ".png") ) # -----(2)

# PdfPagesのインポート
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt

# pdfファイルの初期化
pp = PdfPages('multipage.pdf')

# figureをセーブする
pp.savefig()

# pdfファイルをクローズする。
pp.close()

### グラフの生成 - ここまで

### エクセルファイルの生成 - ここから
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Color, PatternFill, Font, Border
from openpyxl import Workbook

# Excelファイルを開きます
wb = Workbook()
ws = wb.active

sheetNames = wb.sheetnames
ws = wb[sheetNames[0]]  # ここでは例として1つ目のシートを取得しています

# データをセットする
base_row = 10
data_row = 11

ws['A' + str(base_row)] = 'level'
ws['B' + str(base_row)] = 'Lv'
ws['C' + str(base_row)] = 'Lv_Nom'
ws['D' + str(base_row)] = 'level'
ws['E' + str(base_row)] = 'Lv'
ws['F' + str(base_row)] = 'Lv_Nom'

count = data_row
for level, lv, lv_Normalize in zip(csvA.lfl_level, csvA.lfl_lv, csvA.lfl_lv_Normalize):
    ws['A' + str(count)] = level
    ws['B' + str(count)] = lv
    ws['C' + str(count)] = lv_Normalize
    count += 1

count = data_row
for level, lv, lv_Normalize in zip(csvB.lfl_level, csvB.lfl_lv, csvB.lfl_lv_Normalize):
    ws['D' + str(count)] = level
    ws['E' + str(count)] = lv
    ws['F' + str(count)] = lv_Normalize
    count += 1

# 出力するグラフのサイズ
chtWidth = 24
chtHeight = 12

# 1つ目の散布図を用意します
cht1 = openpyxl.chart.ScatterChart()
cht1.title = '3120-2460 Lv正規化'
cht1.x_axis.title = 'Level'
cht1.y_axis.axId = 200
cht1.y_axis.title = 'Lv'
cht1.height = chtHeight
cht1.width = chtWidth

# 2つ目の散布図を用意します
cht2 = openpyxl.chart.ScatterChart()
cht2.title = '3120-2460 Lv64以下'
cht2.x_axis.title = 'Level'
cht2.y_axis.title = "Lv"
cht2.y_axis.majorGridLines = None
cht2.height = chtHeight
cht2.width = chtWidth

# グラフ化するデータを参照する
cht1_startRow = data_row
cht1_endRow = data_row + 10
cht2_startRow = data_row
cht2_endRow = data_row + 4

# Excelのデータ参照した変数を用意する
cht1_levelValues = openpyxl.chart.Reference(ws, min_col=1, min_row=cht1_startRow, max_row=cht1_endRow)
cht1_left_LvNormalize = openpyxl.chart.Reference(ws, min_col=3, min_row=cht1_startRow, max_row=cht1_endRow)
cht1_right_LvNormalize = openpyxl.chart.Reference(ws, min_col=6, min_row=cht1_startRow, max_row=cht1_endRow)
cht2_levelValues = openpyxl.chart.Reference(ws, min_col=1, min_row=cht2_startRow, max_row=cht2_endRow)
cht2_left_LvNormalize = openpyxl.chart.Reference(ws, min_col=3, min_row=cht2_startRow, max_row=cht2_endRow)
cht2_right_LvNormalize = openpyxl.chart.Reference(ws, min_col=6, min_row=cht2_startRow, max_row=cht2_endRow)

# 系列を用意し、データ参照を入力する 最初の行を凡例とする
cht1_left_s1 = openpyxl.chart.Series(cht1_left_LvNormalize, cht1_levelValues, title_from_data=False, title='3120')
cht1_right_s2 = openpyxl.chart.Series(cht1_right_LvNormalize, cht1_levelValues, title_from_data=False, title='2460')
cht2_left_s1 = openpyxl.chart.Series(cht2_left_LvNormalize, cht2_levelValues, title_from_data=False, title='3120')
cht2_right_s2 = openpyxl.chart.Series(cht2_right_LvNormalize, cht2_levelValues, title_from_data=False, title='2460')

# グラフの書式設定をする
cht1_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
cht1_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
cht1_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
cht1_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

cht1_right_s2.graphicalProperties.line.solidFill = "c0504d"
cht1_right_s2.marker.symbol = "x"
cht1_right_s2.marker.graphicalProperties.solidFill = "c0504d"
cht1_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"

cht2_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
cht2_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
cht2_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
cht2_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

cht2_right_s2.graphicalProperties.line.solidFill = "c0504d"
cht2_right_s2.marker.symbol = "x"
cht2_right_s2.marker.graphicalProperties.solidFill = "c0504d"
cht2_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"


# Chartに系列を追加する
# 1つ目のグラフに系列(s1,s2)を、2つ目のグラフに2つの系列(s3, s4)を追加している。
cht1.series.append(cht1_left_s1)
cht1.series.append(cht1_right_s2)
cht2.series.append(cht2_left_s1)
cht2.series.append(cht2_right_s2)

# y軸を2軸もつグラフに設定する(グラフを足し合わせる)
# 2つ目のグラフのy軸を右側に設定する
cht2.y_axis.crosses = "max"
# cht2 += cht1

# Excelシートにグラフを貼り付ける
graphInsertCol = 12 # グラフを挿入する列番号
inColLetter = get_column_letter(graphInsertCol)
inRow = 2 # グラフを挿入する行番号
inCellLetter = inColLetter + str(inRow) # グラフを挿入するセルの位置をExcel形式で作る
ws.add_chart(cht1, inCellLetter)
inCellLetter = inColLetter + str(30) # グラフを挿入するセルの位置をExcel形式で作る
ws.add_chart(cht2, inCellLetter)

outfilename = csvA.str_filename + "_" + csvB.str_filename + ".xlsx"
outfilename = outfilename.replace('.csv', '')

wb.save( outfilename )

### エクセルファイルの生成 - ここまで

