
class MyClass:
    def __init__( self):
        print(' constructer')

    def method1( self, a):
        print(a)
    
    def method2(self):
        print('sefl type: {}'.format(type(self)))
        print('self ref: {}'.format(self))

instance = MyClass() # constructer

instance.method1(' hello') # hello
instance.method2()


class TestPrivate:
    def __init__( self):
        self.var1 = 'var1'
        self.__var2 = 'var2' # PRIVATE
    
    def method1( self):
        print(' method 1')
    
    def __method2( self): # PRIVATE
        print(' method 2')
        
    def method3( self):
        print( self.var1)
        print( self.__var2)
        self.method1()
        self.__method2()

instance_2 = TestPrivate()
print( instance_2.var1)
# print( instance_2.__var2)

instance_2.method1()
# instance_2.__method2()
instance_2.method3()


