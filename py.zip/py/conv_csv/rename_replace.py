# 特定の文字列を置換する
import shutil, os
import sys

argvs = sys.argv  # コマンドライン引数を格納したリストの取得
argc = len(argvs) # 引数の個数
# デバッグプリント
# print(argvs)
# print(argc)

if (argc != 3):   # 引数が足りない場合は、その旨を表示
    print( 'Usage: # python ' + argvs[0] + 'henkoumae_mojiretu henkougo_mojiretu')
    quit()         # プログラムの終了

for filename in os.listdir( os.getcwd() ):
    # print( filename )
    if argvs[1] in filename:
        dst = filename.replace(argvs[1], argvs[2])
        print( filename + '==>' + dst )
        shutil.move(filename, dst)
