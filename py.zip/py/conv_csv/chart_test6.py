import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Color, PatternFill, Font, Border

# Excelファイルを開きます
# outputFilePath = 'C:\extract.xlsx' # 出力したいExcelファイル名を指定してください
outputFilePath = 'extract_a.xlsx' # 出力したいExcelファイル名を指定してください
wb = openpyxl.load_workbook(outputFilePath)
sheetNames = wb.sheetnames
ws = wb[sheetNames[0]]  # ここでは例として1つ目のシートを取得しています

# 出力するグラフのサイズ
chtWidth = 24
chtHeight = 12

# 1つ目の散布図を用意します
cht1 = openpyxl.chart.ScatterChart()
cht1.title = '3120-2460 Lv正規化'
cht1.x_axis.title = 'Level'
cht1.y_axis.axId = 200
cht1.y_axis.title = 'Lv'
cht1.height = chtHeight
cht1.width = chtWidth

# 2つ目の散布図を用意します
cht2 = openpyxl.chart.ScatterChart()
cht2.title = '3120-2460 Lv64以下'
cht2.x_axis.title = 'Level'
cht2.y_axis.title = "Lv"
cht2.y_axis.majorGridLines = None
cht2.height = chtHeight
cht2.width = chtWidth

# グラフ化するデータを参照する
cht1_startRow = 11
cht1_endRow = 75
cht2_startRow = 11
cht2_endRow = 27

# Excelのデータ参照した変数を用意する
cht1_levelValues = openpyxl.chart.Reference(ws, min_col=1, min_row=cht1_startRow, max_row=cht1_endRow)
cht1_left_LvNormalize = openpyxl.chart.Reference(ws, min_col=3, min_row=cht1_startRow, max_row=cht1_endRow)
cht1_right_LvNormalize = openpyxl.chart.Reference(ws, min_col=6, min_row=cht1_startRow, max_row=cht1_endRow)
cht2_levelValues = openpyxl.chart.Reference(ws, min_col=1, min_row=cht2_startRow, max_row=cht2_endRow)
cht2_left_LvNormalize = openpyxl.chart.Reference(ws, min_col=3, min_row=cht2_startRow, max_row=cht2_endRow)
cht2_right_LvNormalize = openpyxl.chart.Reference(ws, min_col=6, min_row=cht2_startRow, max_row=cht2_endRow)

# 系列を用意し、データ参照を入力する 最初の行を凡例とする
cht1_left_s1 = openpyxl.chart.Series(cht1_left_LvNormalize, cht1_levelValues, title_from_data=False, title='3120')
cht1_right_s2 = openpyxl.chart.Series(cht1_right_LvNormalize, cht1_levelValues, title_from_data=False, title='2460')
cht2_left_s1 = openpyxl.chart.Series(cht2_left_LvNormalize, cht2_levelValues, title_from_data=False, title='3120')
cht2_right_s2 = openpyxl.chart.Series(cht2_right_LvNormalize, cht2_levelValues, title_from_data=False, title='2460')

# グラフの書式設定をする
cht1_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
cht1_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
cht1_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
cht1_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

cht1_right_s2.graphicalProperties.line.solidFill = "c0504d"
cht1_right_s2.marker.symbol = "x"
cht1_right_s2.marker.graphicalProperties.solidFill = "c0504d"
cht1_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"

cht2_left_s1.graphicalProperties.line.solidFill = "4f81bd" # グラフの線の色
cht2_left_s1.marker.symbol = "diamond" # 各データ点のマーカーの形状
cht2_left_s1.marker.graphicalProperties.solidFill = "4f81bd" # 各データ点のマーカーの塗りつぶし色
cht2_left_s1.marker.graphicalProperties.line.solidFill = "4f81bd" # 各データ点のマーカーの枠の色

cht2_right_s2.graphicalProperties.line.solidFill = "c0504d"
cht2_right_s2.marker.symbol = "x"
cht2_right_s2.marker.graphicalProperties.solidFill = "c0504d"
cht2_right_s2.marker.graphicalProperties.line.solidFill = "c0504d"


# Chartに系列を追加する
# 1つ目のグラフに系列(s1,s2)を、2つ目のグラフに2つの系列(s3, s4)を追加している。
cht1.series.append(cht1_left_s1)
cht1.series.append(cht1_right_s2)
cht2.series.append(cht2_left_s1)
cht2.series.append(cht2_right_s2)

# y軸を2軸もつグラフに設定する(グラフを足し合わせる)
# 2つ目のグラフのy軸を右側に設定する
cht2.y_axis.crosses = "max"
# cht2 += cht1

# Excelシートにグラフを貼り付ける
graphInsertCol = 12 # グラフを挿入する列番号
inColLetter = get_column_letter(graphInsertCol)
inRow = 2 # グラフを挿入する行番号
inCellLetter = inColLetter + str(inRow) # グラフを挿入するセルの位置をExcel形式で作る
ws.add_chart(cht1, inCellLetter)
inCellLetter = inColLetter + str(30) # グラフを挿入するセルの位置をExcel形式で作る
ws.add_chart(cht2, inCellLetter)
wb.save("aaaaaa_6.xlsx")