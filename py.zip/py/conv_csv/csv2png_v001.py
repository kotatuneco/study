### csv情報をcsvA,csvBにセットする - ここから

class CsvCtl:
    val = 100
    str_filename = ""

    str_tag = "White"
    row_level = 0
    row_lv = 4

    str_label_x = ""
    str_label_y = ""

    def __init__(self):
        self.lstr_level : List[str] = []
        self.lstr_lv : List[str] = []
        self.lfl_level : List[float] = []
        self.lfl_lv : List[float] = []
        self.lfl_lv_Normalize : List[float] = []

    def add_lstr_level(self,msg):
        self.lstr_level.append(msg)

import sys
import os,csv

# args = sys.argv
args = ["csv2png.py", "sampleA.csv", "sampleB.csv", "White", "0", "4"]

csvA = CsvCtl()
csvB = CsvCtl()

# 引数ケア - ここから
csvA.str_filename = args[1]
print( csvA.str_filename )
csvB.str_filename = args[2]
print( csvB.str_filename )
csvA.str_tag = args[3]  # "White"
csvA.row_level = int( args[4] )
csvA.row_lv = int( args[5] )
csvB.str_tag = args[3]
csvB.row_level = int( args[4] )
csvB.row_lv = int( args[5] )
# 引数ケア - ここまで

for csvTmp in [csvA, csvB]:
    # work area初期化
    chk_flag = False
    label_flag = False
    with open( csvTmp.str_filename ) as f:
        reader = csv.reader(f)
        for row in reader:
            # 処理データ
            if chk_flag:
                # syorisuru
                if label_flag == False:
                    csvTmp.str_label_x = row[csvTmp.row_level]
                    csvTmp.str_label_y = row[csvTmp.row_lv]
                    label_flag = True
                else:
                    csvTmp.lstr_level.append(row[csvTmp.row_level])
                    csvTmp.lstr_lv.append(row[csvTmp.row_lv])
                    csvTmp.lfl_level.append( float(row[csvTmp.row_level]) )
                    csvTmp.lfl_lv.append( float(row[csvTmp.row_lv]) )
                    # print(row)
            # 処理必要？
            if csvTmp.str_tag in row:
                print("!!!white!!!")
                chk_flag = True
            # print(row)

    # 正規化したデータをセットする
    for value in csvTmp.lfl_lv:
        csvTmp.lfl_lv_Normalize.append( value / csvTmp.lfl_lv[-1] )
    
    # データの確認
    # print( csvTmp.lstr_level )
    # print( csvTmp.lstr_lv )
    # print( csvTmp.lfl_level )
    # print( csvTmp.lfl_lv )
    # print( csvTmp.lfl_lv_Normalize )

### csv情報をcsvA,csvBにセットする - ここまで


### グラフの生成 - ここから
## ほしいグラフは？？？
## [0, 0] - AとB, x:level, y:Lv, 正規化
## [0, 1] - AとB, x:level, y:Lv, 生データ
## [1, 0] - AとB, x:level, y:Lv, 正規化(0-16)
## [1, 1] - AとB, x:level, y:Lv, 生データ(0-16)

import numpy as np
import matplotlib
matplotlib.use('Agg') # -----(1)
import matplotlib.pyplot as plt


# figure
fig = plt.figure()
# ax_1 = fig.add_subplot(1, 2, 1)     #1行2列の1番目
# ax_2 = fig.add_subplot(1, 2, 2)     #1行2列の2番目
ax_1 = fig.add_subplot(2, 1, 1)     #2行1列の1番目
ax_2 = fig.add_subplot(2, 1, 2)     #2行1列の2番目

# plot
ax_1.plot(csvA.lfl_level, csvA.lfl_lv_Normalize, linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
ax_1.plot(csvB.lfl_level, csvB.lfl_lv_Normalize, linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )
ax_2.plot(csvA.lfl_level[:4], csvA.lfl_lv_Normalize[:4], linestyle='--', color='b', marker="h", label=(csvA.str_filename +' x:Level, y:Normalize Lv') )
ax_2.plot(csvB.lfl_level[:4], csvB.lfl_lv_Normalize[:4], linestyle='-', color='#e46409', marker="h", label=(csvB.str_filename +' x:Level, y:Normalize Lv') )

# x axis
# plt.xlim([ csvA.lfl_level[0], csvA.lfl_level[-1] ])
ax_1.set_xticks( csvA.lfl_level )
ax_1.set_xticklabels( csvA.lstr_level )
ax_1.set_xlabel('x')
ax_2.set_xticks( csvA.lfl_level[:4] )
ax_2.set_xticklabels( csvA.lstr_level[:4] )
ax_2.set_xlabel('x')

# y axis
# plt.ylim([ csvA.lfl_lv_Normalize[0], csvA.lfl_lv_Normalize[-1] ])
ax_1.set_yticks( csvA.lfl_lv_Normalize )
ax_1.set_ylabel('y')
ax_2.set_yticks( csvA.lfl_lv_Normalize[:4] )
ax_2.set_ylabel('y')

# legend and title
# ax_1.legend(loc='best')
ax_1.legend(loc='upper left')
# ax_1.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )
ax_1.set_title( ("Lv All") )
# ax_2.legend(loc='best')
ax_2.legend(loc='upper left')
ax_2.set_title( ("Lv -64") )
# ax_2.set_title( ('Plot of ' + csvA.str_filename + csvB.str_filename) )

# save as png
plt.savefig( (csvA.str_filename + "_" + csvB.str_filename + ".png") ) # -----(2)

# PdfPagesのインポート
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt

# pdfファイルの初期化
pp = PdfPages('multipage.pdf')

# figureをセーブする
pp.savefig()

# pdfファイルをクローズする。
pp.close()

### グラフの生成 - ここまで

### エクセルファイルの生成 - ここから


### エクセルファイルの生成 - ここまで

