# 特定の文字列を連番付加する
# https://note.nkmk.me/python-format-zero-hex/
import shutil, os
import sys

argvs = sys.argv  # コマンドライン引数を格納したリストの取得
argc = len(argvs) # 引数の個数
# デバッグプリント
# print(argvs)
# print(argc)

if (argc != 4):   # 引数が足りない場合は、その旨を表示
    print( 'Usage: # python ' + argvs[0] + '対象文字列' + '開始番号(ex.0) 形式(ex.04d')
    print( '04d : 4桁 0埋め 10進数')
    print( '08x : 8桁 0埋め 16進数')
    print( 'd   : 0埋めなし 10進数')
    quit()         # プログラムの終了

suuti = int(argvs[2])
for filename in os.listdir( os.getcwd() ):
    # print( filename )
    if argvs[1] in filename:
        renban = format(suuti, argvs[3])
        renban = '_' + renban
        renban += '.'
        dst = filename.replace('.', renban)
        print( filename + '==>' + dst )
        shutil.move(filename, dst)
        suuti += 1
